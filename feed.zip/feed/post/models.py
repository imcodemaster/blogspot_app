from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
from django.urls import reverse 

# Create your models here.
class Post(models.Model):
    posttitle = models.CharField(max_length = 100)
    postpublished = models.DateTimeField(default=timezone.now)
    postauthor = models.ForeignKey(User, on_delete=models.CASCADE)
    postcontent = models.TextField(null = True, blank = True)
    postcontentimg = models.ImageField(null = True, blank = True)
    postcontentfile = models.FileField(null = True, blank = True)

    def __str__(self):
        return self.posttitle